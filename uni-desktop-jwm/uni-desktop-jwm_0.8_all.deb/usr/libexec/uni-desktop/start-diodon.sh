#!/bin/bash
diodon &
sleep 6s
killall diodon
diodon
